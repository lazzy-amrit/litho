import os
import glob
import pytest
from dotenv import load_dotenv

from litho import (
    Database, Model, TextField, IntegerField, VectorField,
    ForeignKey, IntegrityError
)

load_dotenv()

URL = os.getenv("url")
TOKEN = os.getenv("token")

pytestmark = pytest.mark.skipif(
    not URL or not TOKEN,
    reason="Real server credentials (url, token) not found in environment."
)


class ServerTestUser(Model):
    username = TextField(unique=True)
    score = IntegerField(default=0)


class ServerTestDoc(Model):
    title = TextField()
    vector = VectorField(dim=3)


def test_real_server_direct_libsql():
    db = Database(URL, driver="libsql", auth_token=TOKEN)
    try:
        db.create_tables(ServerTestUser, ServerTestDoc)

        u = ServerTestUser.create(username="real_user_test", score=42)
        assert u.id is not None
        assert ServerTestUser.get(username="real_user_test").score == 42

        # Vector search
        ServerTestDoc.create(title="vec_a", vector=[1.0, 0.0, 0.0])
        ServerTestDoc.create(title="vec_b", vector=[0.0, 1.0, 0.0])
        nearest = list(ServerTestDoc.query().nearest("vector", [1.0, 0.0, 0.0], k=1))
        assert len(nearest) == 1
        assert nearest[0].title == "vec_a"
    finally:
        db.drop_tables(ServerTestDoc, ServerTestUser)
        db.close()


def test_real_server_embedded_replica():
    rep_file = "test_pytest_replica.db"
    for f in glob.glob(rep_file + "*"):
        os.remove(f)

    # Pre-create table on real server
    db_server = Database(URL, driver="libsql", auth_token=TOKEN)
    try:
        db_server.create_tables(ServerTestUser)

        # Embedded replica
        db_rep = Database(rep_file, driver="libsql", sync_url=URL, auth_token=TOKEN)
        ServerTestUser._db = db_rep
        db_rep.sync()

        u = ServerTestUser.create(username="replica_user_test", score=99)
        assert u.id is not None

        db_rep.sync()
        db_rep.close()

        # Verify on server
        ServerTestUser._db = db_server
        assert ServerTestUser.filter(username="replica_user_test").count() == 1
    finally:
        try:
            db_server.drop_tables(ServerTestUser)
        except Exception:
            pass
        db_server.close()
        for f in glob.glob(rep_file + "*"):
            try:
                os.remove(f)
            except Exception:
                pass


def test_real_server_turso_sync():
    sync_file = "test_pytest_turso_sync.db"
    for f in glob.glob(sync_file + "*"):
        os.remove(f)

    http_url = URL.replace("libsql://", "https://")
    try:
        db_sync = Database(sync_file, driver="turso", remote_url=http_url, auth_token=TOKEN)
        db_sync.create_tables(ServerTestUser)

        ServerTestUser.create(username="turso_sync_user", score=88)
        db_sync.push()
        db_sync.pull()
        db_sync.sync()

        assert ServerTestUser.filter(username="turso_sync_user").count() == 1
        db_sync.drop_tables(ServerTestUser)
        db_sync.push()
        db_sync.close()
    finally:
        for f in glob.glob(sync_file + "*"):
            try:
                os.remove(f)
            except Exception:
                pass
