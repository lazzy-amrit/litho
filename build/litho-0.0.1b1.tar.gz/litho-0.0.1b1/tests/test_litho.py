import os
import datetime
import pytest
from dotenv import load_dotenv

from litho import (
    Database, Model, Q, Query, Result,
    Field, IntegerField, FloatField, TextField, BooleanField,
    DateTimeField, DateField, JSONField, BlobField, VectorField, ForeignKey,
    LithoError, DatabaseError, IntegrityError, ValidationError, FieldError,
    UnsupportedError, DoesNotExist, MultipleObjectsReturned,
)

load_dotenv()


# ==============================================================================
# Model Definitions for Testing
# ==============================================================================

class Author(Model):
    name = TextField(unique=True, max_length=50)
    bio = TextField(null=True)
    is_active = BooleanField(default=True)
    rating = FloatField(default=5.0)
    meta = JSONField(null=True)
    created = DateTimeField(auto_now_add=True)
    updated = DateTimeField(auto_now=True)


class Article(Model):
    author = ForeignKey(Author, backref="articles", on_delete="CASCADE")
    title = TextField(max_length=100)
    content = TextField()
    views = IntegerField(default=0)
    published_date = DateField(null=True)
    thumbnail = BlobField(null=True)


class HookModel(Model):
    name = TextField()
    log = TextField(default="")

    def before_save(self):
        self.log += "before_save;"

    def after_save(self):
        self.log += "after_save;"

    def before_delete(self):
        self.log += "before_delete;"


class Tag(Model):
    tag = TextField(unique=True)


# ==============================================================================
# Fixtures
# ==============================================================================

@pytest.fixture(params=["sqlite", "libsql", "turso"])
def db(request):
    driver = request.param
    db_inst = Database(":memory:", driver=driver)
    db_inst.create_tables(Author, Article, HookModel, Tag)
    yield db_inst
    try:
        db_inst.drop_tables(Article, HookModel, Tag, Author)
    except Exception:
        pass
    db_inst.close()


# ==============================================================================
# Core Model & Field Tests
# ==============================================================================

def test_field_validation(db):
    # Valid
    a = Author.create(name="Valid Author", bio="A writer", is_active=True, rating=4.8)
    assert a.id is not None
    assert a.name == "Valid Author"
    assert a.is_active is True

    # Bad text max_length
    with pytest.raises(ValidationError):
        Author.create(name="x" * 60)

    # Bad boolean
    with pytest.raises(ValidationError):
        Author.create(name="Bad Bool", is_active="not_a_bool")

    # Bad float
    with pytest.raises(ValidationError):
        Author.create(name="Bad Float", rating="abc")


def test_crud_and_hooks(db):
    h = HookModel.create(name="HookTest")
    assert "before_save;" in h.log
    assert "after_save;" in h.log

    h.name = "HookUpdated"
    h.save()
    assert h.name == "HookUpdated"

    # Refresh
    h.refresh()
    assert h.name == "HookUpdated"

    # Delete
    h.delete()
    assert HookModel.filter(id=h.id).count() == 0


def test_get_or_create_and_upsert(db):
    # get_or_create
    tag1, created = Tag.get_or_create(tag="python")
    assert created is True
    assert tag1.tag == "python"

    tag2, created2 = Tag.get_or_create(tag="python")
    assert created2 is False
    assert tag1.id == tag2.id

    # upsert
    author1 = Author.upsert("name", name="UpsertAuthor", bio="Initial", rating=3.0)
    assert author1.bio == "Initial"

    author2 = Author.upsert("name", name="UpsertAuthor", bio="Updated Bio", rating=4.0)
    assert author2.id == author1.id
    assert author2.bio == "Updated Bio"
    assert author2.rating == 4.0


def test_bulk_create_and_queries(db):
    authors = [Author(name=f"Author_{i}", rating=float(i)) for i in range(10)]
    count = Author.bulk_create(authors)
    assert count == 10
    assert Author.count() == 10

    # Lookups
    assert Author.filter(name__startswith="Author_").count() == 10
    assert Author.filter(rating__gte=5.0).count() == 5
    assert Author.filter(name__in=["Author_1", "Author_2"]).count() == 2
    assert Author.filter(rating__between=(3.0, 6.0)).count() == 4
    assert Author.filter(bio__isnull=True).count() == 10

    # Q combinations
    q_res = Author.filter(Q(rating__lt=2.0) | Q(rating__gte=8.0)).all()
    assert len(q_res) == 4

    # Ordering & paging
    first_two = Author.order_by("-rating").paginate(1, per_page=2).all()
    assert [a.rating for a in first_two] == [9.0, 8.0]


def test_aggregates(db):
    for i in range(1, 6):
        Author.create(name=f"Agg_{i}", rating=float(i))
    assert Author.query().sum("rating") == 15.0
    assert Author.query().avg("rating") == 3.0
    assert Author.query().min("rating") == 1.0
    assert Author.query().max("rating") == 5.0


def test_relationships(db):
    author = Author.create(name="RelAuthor")
    art1 = Article.create(author=author, title="Post 1", content="Text 1")
    art2 = Article.create(author=author, title="Post 2", content="Text 2")

    # Forward lookup
    assert art1.author.name == "RelAuthor"

    # Reverse lookup via backref
    assert author.articles.count() == 2

    # Query across relationship
    assert Article.filter(author__name="RelAuthor").count() == 2
    assert Article.filter(author__name__startswith="Rel").count() == 2

    # Cascade delete
    author.delete()
    assert Article.count() == 0


def test_transactions_and_savepoints(db):
    with db.atomic():
        Author.create(name="Tx1")
        try:
            with db.atomic():
                Author.create(name="Tx2_nested_fail")
                raise RuntimeError("Nested failure")
        except RuntimeError:
            pass
        Author.create(name="Tx3")

    assert Author.filter(name="Tx1").count() == 1
    assert Author.filter(name="Tx2_nested_fail").count() == 0
    assert Author.filter(name="Tx3").count() == 1


def test_schema_modifications(db):
    class AuthorV2(Author):
        country = TextField(null=True)
        class Meta:
            table = "author"

    added = db.add_missing_columns(AuthorV2)
    assert "author.country" in added
    assert "country" in db.columns("author")


def test_big_integer(db):
    class BigTable(Model):
        val = IntegerField()

    db.create_tables(BigTable)
    big = 2**56 + 789
    b = BigTable.create(val=big)
    assert BigTable.get(b.id).val == big
    db.drop_tables(BigTable)


# ==============================================================================
# Vector Search (LibSQL & Turso)
# ==============================================================================

@pytest.mark.parametrize("driver", ["libsql", "turso"])
def test_vector_search(driver):
    class ItemVector(Model):
        name = TextField()
        vec = VectorField(dim=3)

    db_inst = Database(":memory:", driver=driver)
    db_inst.create_tables(ItemVector)

    ItemVector.create(name="vec_x", vec=[1.0, 0.0, 0.0])
    ItemVector.create(name="vec_y", vec=[0.0, 1.0, 0.0])
    ItemVector.create(name="vec_z", vec=[0.707, 0.707, 0.0])

    results = list(ItemVector.query().nearest("vec", [1.0, 0.0, 0.0], k=2))
    assert len(results) == 2
    assert results[0].name == "vec_x"
    assert round(results[0].distance, 3) == 0.0

    db_inst.drop_tables(ItemVector)
    db_inst.close()


def test_sqlite_vector_unsupported():
    class BadVector(Model):
        vec = VectorField(dim=3)

    db_inst = Database(":memory:", driver="sqlite")
    with pytest.raises(UnsupportedError):
        db_inst.create_tables(BadVector)
    db_inst.close()


# ==============================================================================
# Turso Local MVCC
# ==============================================================================

def test_turso_mvcc(tmp_path):
    db_file = str(tmp_path / "mvcc.db")
    db_inst = Database(db_file, driver="turso", mvcc=True)
    db_inst.create_tables(Tag)

    with db_inst.atomic(concurrent=True):
        Tag.create(tag="mvcc_tag")

    assert Tag.get(tag="mvcc_tag") is not None
    db_inst.close()
